package models;

public enum TipoOcorrencia {
    CARRO_QUEBRADO, BATIDA_CARRO
}
