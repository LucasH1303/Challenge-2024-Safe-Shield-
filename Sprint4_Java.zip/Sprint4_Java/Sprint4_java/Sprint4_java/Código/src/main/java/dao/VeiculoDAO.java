package dao;

import utils.ConnectionFactory;
import models.Veiculo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class VeiculoDAO {

    // Método para inserir um veículo no banco de dados
    public void insert(Veiculo veiculo) {
        String sql = "INSERT INTO veiculo (marca, modelo, dataFabricacao, placa) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, veiculo.getMarca());
            stmt.setString(2, veiculo.getModelo());
            stmt.setDate(3, java.sql.Date.valueOf(veiculo.getDataFabricacao()));
            stmt.setString(4, veiculo.getPlaca());

            stmt.executeUpdate();
            System.out.println("Veículo inserido com sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao inserir veículo: " + e.getMessage());
        }
    }
}

