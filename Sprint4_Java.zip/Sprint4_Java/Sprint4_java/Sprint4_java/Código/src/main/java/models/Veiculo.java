package models;

import controllers.CondutorVeiculo;

import java.time.LocalDate;

public class Veiculo {
    private CondutorVeiculo condutor;
    private String marca;
    private String modelo;
    private LocalDate dataFabricacao;
    private String placa;

    public Veiculo() {
    }

    public Veiculo(CondutorVeiculo condutor, String marca, String modelo, LocalDate dataFabricacao, String placa) {
        this.setCondutor(condutor);
        this.setMarca(marca);
        this.setModelo(modelo);
        this.setDataFabricacao(dataFabricacao);
        this.setPlaca(placa);
    }

    public CondutorVeiculo getCondutor() {
        return condutor;
    }

    public void setCondutor(CondutorVeiculo condutor) {
        this.condutor = condutor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public LocalDate getDataFabricacao() {
        return dataFabricacao;
    }

    public void setDataFabricacao(LocalDate dataFabricacao) {
        this.dataFabricacao = dataFabricacao;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public void exibirInformacoes() {
        System.out.println("VEICULO");
        System.out.println("Marca: " + getMarca());
        System.out.println("Modelo: " + getModelo());
        System.out.println("Ano de Fabricação: " + getDataFabricacao());
        System.out.println("Placa: " + getPlaca());
    }
}
