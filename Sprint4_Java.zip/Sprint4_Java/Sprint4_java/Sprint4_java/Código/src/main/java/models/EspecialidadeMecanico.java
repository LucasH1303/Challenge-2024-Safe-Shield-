package models;

public enum EspecialidadeMecanico {
    MOTOR, ARMOTECIMENTO
}
