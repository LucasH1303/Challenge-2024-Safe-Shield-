package models;

public class OrcamentoDesconto {
    private double valor;
    private TipoServico tipoDeServico;
    private TipoOrcamento tipoOrcamento;
    private String descricaoOrcamento;

    // Construtor padrão
    public OrcamentoDesconto() { }

    // Construtor com parâmetros
    public OrcamentoDesconto(double valor, TipoServico tipoDeServico, TipoOrcamento tipoOrcamento, String descricaoOrcamento) {
        this.setValor(valor);
        this.setTipoDeServico(tipoDeServico);
        this.setTipoOrcamento(tipoOrcamento);
        this.setDescricaoOrcamento(descricaoOrcamento);
    }

    // Getters e Setters
    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }

    public TipoServico getTipoDeServico() { return tipoDeServico; }
    public void setTipoDeServico(TipoServico tipoDeServico) { this.tipoDeServico = tipoDeServico; }

    public TipoOrcamento getTipoOrcamento() { return tipoOrcamento; }
    public void setTipoOrcamento(TipoOrcamento tipoOrcamento) { this.tipoOrcamento = tipoOrcamento; }

    public String getDescricaoOrcamento() { return descricaoOrcamento; }
    public void setDescricaoOrcamento(String descricaoOrcamento) { this.descricaoOrcamento = descricaoOrcamento; }

    // Método para calcular orçamento com desconto
    public double calcularOrcamentoComDesconto() {
        double desconto = 0.0;

        // Aplica um desconto de 10% para orçamentos do tipo ESPECIAL
        if (this.tipoOrcamento == TipoOrcamento.ESPECIAL) {
            desconto = 0.10;
        }

        double valorFinal = this.valor - (this.valor * desconto);
        System.out.println("Valor final com desconto: " + valorFinal + " REAIS");
        return valorFinal;
    }

    // Método para consultar o orçamento e exibir as informações
    public void consultarOrcamento() {
        System.out.println("Tipo de Serviço: " + getTipoDeServico());
        System.out.println("Tipo de Orçamento: " + getTipoOrcamento());
        System.out.println("Descrição: " + getDescricaoOrcamento());
        System.out.println("Valor Estimado: " + getValor() + " REAIS");
    }
}

