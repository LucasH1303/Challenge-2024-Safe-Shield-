package models;

import java.time.LocalDate;

public class EspecificacoesVeiculo {

    private String marca;
    private String modelo;
    private LocalDate dataFabricacao;
    private String placa;

    // Construtor padrão
    public EspecificacoesVeiculo() { }

    // Construtor com parâmetros
    public EspecificacoesVeiculo(String marca, String modelo, LocalDate dataFabricacao, String placa) {
        this.setMarca(marca);
        this.setModelo(modelo);
        this.setDataFabricacao(dataFabricacao);
        this.setPlaca(placa);
    }

    // Getters e Setters
    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public LocalDate getDataFabricacao() { return dataFabricacao; }
    public void setDataFabricacao(LocalDate dataFabricacao) { this.dataFabricacao = dataFabricacao; }

    public String getPlaca() { return placa; }
    public void setPlaca(String placa) { this.placa = placa; }

    // Método para exibir as informações do veículo
    public void exibirInformacoes() {
        System.out.println("Marca: " + getMarca());
        System.out.println("Modelo: " + getModelo());
        System.out.println("Ano de Fabricação: " + getDataFabricacao());
        System.out.println("Placa: " + getPlaca());
    }

    // Método para verificar a idade do veículo
    public boolean verificarIdadeVeiculo() {
        LocalDate hoje = LocalDate.now();
        int idade = hoje.getYear() - this.dataFabricacao.getYear();

        if (idade > 5) {
            System.out.println("Veículo com mais de 5 anos, elegível para serviço especial.");
            return true;
        } else {
            System.out.println("Veículo com menos de 5 anos.");
            return false;
        }
    }
}

