package controllers;

import models.Endereco;
import models.Telefone;

import java.time.LocalDate;

public class Usuario {
    private String email;
    private String nomeUsuario;
    private String senha;
    private Telefone telefone;
    private Endereco endereco;
    private LocalDate dataNascimento;

    public Usuario() {
    }

    public Usuario(String email, String nomeUsuario, String senha, Telefone telefone, Endereco endereco, LocalDate dataNascimento) {
        this.setEmail(email);
        this.setNomeUsuario(nomeUsuario);
        this.setSenha(senha);
        this.setTelefone(telefone);
        this.setEndereco(endereco);
        this.setDataNascimento(dataNascimento);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public Telefone getTelefone() {
        return telefone;
    }

    public void setTelefone(Telefone telefone) {
        this.telefone = telefone;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public void ConsultarRegistro(){
        System.out.println("USUARIO");
        System.out.println("Email: " + getEmail());
        System.out.println("Nome Usuario: " + getNomeUsuario());
        System.out.println("Senha: " + getSenha());
        System.out.println("Telefone: " + getTelefone());
        System.out.println("Endereco: " + getEndereco());
        System.out.println("Data de Nascimento: " + getDataNascimento());
    }

    public void consultarRegistro() {
    }
}
