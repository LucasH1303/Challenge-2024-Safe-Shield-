package br.com.fiap;

import controllers.CondutorVeiculo;
import controllers.Orcamento;
import controllers.RegistroOcorrencia;
import controllers.Usuario;
import models.*;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

       Usuario usuario = new Usuario();
       usuario.setEmail("reirir@gmail.com");
       usuario.setNomeUsuario("RICKINHO");
       usuario.setSenha("123456");
       usuario.setDataNascimento(LocalDate.of(2000, 2, 10));
       usuario.setEndereco(new Endereco("07054-340","Rua Pastor Alemão", "Vila Regina", "222", "MecanicoForza"));
       usuario.setTelefone(new Telefone("55", "11", "9585899544"));
       usuario.ConsultarRegistro();

       System.out.println();

       CondutorVeiculo condutor = new CondutorVeiculo();
       condutor.setNome("JOSÉ");
       condutor.setRg("22732823274");
       condutor.setCpf("37378343854");
       condutor.setCnh("485858588585855858");
       condutor.setDataNascimento(LocalDate.of(2000, 5, 15));
       condutor.ConsultarInformacoes();

       System.out.println();

       Veiculo carro = new Veiculo();
       carro.setMarca("FIAT");
       carro.setModelo("Highline");
       carro.setDataFabricacao(LocalDate.of(2020, 1, 10));
       carro.setPlaca("A18E29");
       carro.exibirInformacoes();

       System.out.println();

       Mecanico mecanico = new Mecanico();
       mecanico.setNome("Mecanico");
       mecanico.setEspecialidade(EspecialidadeMecanico.MOTOR);
       mecanico.setTelefone(new Telefone("55", "11", "9585899544"));
       mecanico.ConsultarInformacoes();

       System.out.println();

       RegistroOcorrencia ocorrencia = new RegistroOcorrencia();
       ocorrencia.setTipoOcorrencia(TipoOcorrencia.BATIDA_CARRO);
       ocorrencia.setDescricaoOcorrencia("MEU CARRO QUEBROU :(");
       ocorrencia.setDataOcorrencia(LocalDate.of(2024, 5, 23));
       ocorrencia.registrarOcorrencia();

       System.out.println();

       Orcamento orcamento = new Orcamento();
       orcamento.setTipoDeServico(TipoServico.GUINCHO);
       orcamento.setDescricaoOrcamento("Apartir do serviço selecionado nós da SAFESHIELD forneceremos as melhores condições para seu veículo");
       orcamento.setTipoOrcamento(TipoOrcamento.ESPECIAL);
       orcamento.setValor(1000);
       orcamento.ConsultarOrcamento();

    }
}