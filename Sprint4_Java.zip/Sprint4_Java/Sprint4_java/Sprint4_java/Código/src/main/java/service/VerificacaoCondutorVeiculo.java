package service;
import java.time.LocalDate;

public class VerificacaoCondutorVeiculo {
    private String nome;
    private String rg;
    private String cpf;
    private String cnh;
    private LocalDate dataNascimento;

    public VerificacaoCondutorVeiculo() { }

    public VerificacaoCondutorVeiculo(String nome, String rg, String cpf, String cnh, LocalDate dataNascimento) {
        this.setNome(nome);
        this.setRg(rg);
        this.setCpf(cpf);
        this.setCnh(cnh);
        this.setDataNascimento(dataNascimento);
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getRg() { return rg; }
    public void setRg(String rg) { this.rg = rg; }
    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }
    public String getCnh() { return cnh; }
    public void setCnh(String cnh) { this.cnh = cnh; }
    public LocalDate getDataNascimento() { return dataNascimento; }
    public void setDataNascimento(LocalDate dataNascimento) { this.dataNascimento = dataNascimento; }

    public void consultarInformacoes() {
        System.out.println("Nome Condutor: " + getNome());
        System.out.println("Data de Nascimento: " + getDataNascimento());
        System.out.println("RG Condutor: " + getRg());
        System.out.println("CPF Condutor: " + getCpf());
        System.out.println("CNH Condutor: " + getCnh());
    }

    // Validação do condutor
    public boolean validarCondutor() {
        LocalDate hoje = LocalDate.now();
        int idade = hoje.getYear() - this.dataNascimento.getYear();
        if (idade < 18) {
            System.out.println("O condutor deve ser maior de 18 anos.");
            return false;
        }

        if (this.cnh.length() != 11) {
            System.out.println("A CNH deve conter 11 dígitos.");
            return false;
        }

        System.out.println("Condutor validado com sucesso.");
        return true;
    }

    @Override
    public String toString() {
        return "CondutorVeiculo{" +
                "nome='" + nome + '\'' +
                ", rg='" + rg + '\'' +
                ", cpf='" + cpf + '\'' +
                ", cnh='" + cnh + '\'' +
                ", dataNascimento=" + dataNascimento +
                '}';
    }
}
