package controllers;
import models.TipoOcorrencia;
import models.Veiculo;

import java.time.LocalDate;

public class RegistroOcorrencia {
    private TipoOcorrencia tipoOcorrencia;
    private LocalDate dataOcorrencia;
    private String descricaoOcorrencia;

    public RegistroOcorrencia() { }

    public RegistroOcorrencia(TipoOcorrencia tipoOcorrencia, LocalDate dataOcorrencia, String descricaoOcorrencia) {
        this.setTipoOcorrencia(tipoOcorrencia);
        this.setDataOcorrencia(dataOcorrencia);
        this.setDescricaoOcorrencia(descricaoOcorrencia);
    }

    public TipoOcorrencia getTipoOcorrencia() { return tipoOcorrencia; }
    public void setTipoOcorrencia(TipoOcorrencia tipoOcorrencia) { this.tipoOcorrencia = tipoOcorrencia; }
    public LocalDate getDataOcorrencia() { return dataOcorrencia; }
    public void setDataOcorrencia(LocalDate dataOcorrencia) { this.dataOcorrencia = dataOcorrencia; }
    public String getDescricaoOcorrencia() { return descricaoOcorrencia; }
    public void setDescricaoOcorrencia(String descricaoOcorrencia) { this.descricaoOcorrencia = descricaoOcorrencia; }

    // Método para registrar uma ocorrência
    public void registrarOcorrencia(CondutorVeiculo condutor, Veiculo veiculo) {

    }

    public void consultarOcorrencia() {
        System.out.println("Tipo de Ocorrência: " + getTipoOcorrencia());
        System.out.println("Data: " + getDataOcorrencia());
        System.out.println("Descrição: " + getDescricaoOcorrencia());
    }

    public void registrarOcorrencia() {
    }
}
