package controllers;

import models.TipoOcorrencia;

import java.time.LocalDate;

public class Ocorrencia {
    private TipoOcorrencia tipoOcorrencia;
    private LocalDate horaOcorrencia;
    private LocalDate dataOcorrencia;
    private String descricaoOcorrencia;

    public Ocorrencia() {
    }

    public Ocorrencia(TipoOcorrencia tipoOcorrencia, LocalDate horaOcorrencia, LocalDate dataOcorrencia, String descricaoOcorrencia) {
        this.setTipoOcorrencia(tipoOcorrencia);
        this.setHoraOcorrencia(horaOcorrencia);
        this.setDataOcorrencia(dataOcorrencia);
        this.setDescricaoOcorrencia(descricaoOcorrencia);
    }

    public TipoOcorrencia getTipoOcorrencia() {
        return tipoOcorrencia;
    }

    public void setTipoOcorrencia(TipoOcorrencia tipoOcorrencia) {
        this.tipoOcorrencia = tipoOcorrencia;
    }

    public LocalDate getHoraOcorrencia() {
        return horaOcorrencia;
    }

    public void setHoraOcorrencia(LocalDate horaOcorrencia) {
        this.horaOcorrencia = horaOcorrencia;
    }

    public LocalDate getDataOcorrencia() {
        return dataOcorrencia;
    }

    public void setDataOcorrencia(LocalDate dataOcorrencia) {
        this.dataOcorrencia = dataOcorrencia;
    }

    public String getDescricaoOcorrencia() {
        return descricaoOcorrencia;
    }

    public void setDescricaoOcorrencia(String descricaoOcorrencia) {
        this.descricaoOcorrencia = descricaoOcorrencia;
    }

    public String registrarOcorrencia() {
        System.out.println("TipoOcorrencia: " + getTipoOcorrencia());
        System.out.println("Descricao: " + getDescricaoOcorrencia());
        System.out.println("Data: " + getDataOcorrencia());
        System.out.println("Hora: " + getHoraOcorrencia());
        return ("Ocorrencia registrada com sucesso!");
    }
}
