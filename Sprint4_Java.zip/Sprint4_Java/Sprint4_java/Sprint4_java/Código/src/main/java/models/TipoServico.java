package models;

public enum TipoServico {
    GUINCHO, MECANICA
}
