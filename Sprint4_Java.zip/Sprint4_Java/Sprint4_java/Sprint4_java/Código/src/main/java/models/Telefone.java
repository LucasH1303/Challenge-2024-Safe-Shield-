package models;

public class Telefone {
    private String ddi;
    private String ddd;
    private String numero;

    public Telefone() {
    }

    public Telefone(String ddi, String ddd, String numero) {
        this.setDdi(ddi);
        this.setDdd(ddd);
        this.setNumero(numero);
    }

    public String getDdi() {
        return ddi;
    }

    public void setDdi(String ddi) {
        this.ddi = ddi;
    }

    public String getDdd() {
        return ddd;
    }

    public void setDdd(String ddd) {
        this.ddd = ddd;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }
}
