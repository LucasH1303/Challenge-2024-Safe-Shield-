package models;

public class Mecanico {
    private String nome;
    private EspecialidadeMecanico especialidade;
    private Telefone telefone;

    public Mecanico() {
    }

    public Mecanico(String nome, EspecialidadeMecanico especialidade) {
        this.setNome(nome);
        this.setEspecialidade(especialidade);
    }

    public Mecanico(String carlos, EspecialidadeMecanico especialidadeMecanico, Telefone telefoneMecanico) {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public EspecialidadeMecanico getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(EspecialidadeMecanico especialidade) {
        this.especialidade = especialidade;
    }

    public Telefone getTelefone() {
        return telefone;
    }

    public void setTelefone(Telefone telefone) {
        this.telefone = telefone;
    }

    public void ConsultarInformacoes() {
        System.out.println("Nome Mecanico: " + getNome());
        System.out.println("Especialidade Mecanico: " + getEspecialidade());
        System.out.println("Telefone Mecanico: " + getTelefone());
    }


}
