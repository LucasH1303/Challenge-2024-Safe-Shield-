package models;

public enum TipoOrcamento {
    ESPECIAL, CONVENCIONAL
}
