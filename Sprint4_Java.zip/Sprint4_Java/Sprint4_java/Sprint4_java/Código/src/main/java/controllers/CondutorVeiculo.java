package controllers;

import java.time.LocalDate;

public class CondutorVeiculo {
    private String nome;
    private String rg;
    private String cpf;
    private String cnh;
    private LocalDate dataNascimento;

    public CondutorVeiculo() {
    }

    public CondutorVeiculo(String nome, String rg, String cpf, String cnh, LocalDate dataNascimento) {
        this.setNome(nome);
        this.setRg(rg);
        this.setCpf(cpf);
        this.setCnh(cnh);
        this.setDataNascimento(dataNascimento);
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCnh() {
        return cnh;
    }

    public void setCnh(String cnh) {
        this.cnh = cnh;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public void ConsultarInformacoes(){
        System.out.println("Nome Condutor: " + getNome());
        System.out.println("Data de Nascimento: " + getDataNascimento());
        System.out.println("RG Condutor: " + getRg());
        System.out.println("CPF Condutor: " + getCpf());
        System.out.println("CNH Condutor: " + getCnh());
    }

    @Override
    public String toString() {
        return "CondutorVeiculo{" +
                "nome='" + nome + '\'' +
                ", rg='" + rg + '\'' +
                ", cpf='" + cpf + '\'' +
                ", cnh='" + cnh + '\'' +
                ", dataNascimento=" + dataNascimento +
                '}';
    }

    public boolean validarCondutor() {
        return false;
    }

    public void consultarInformacoes() {
    }
}
