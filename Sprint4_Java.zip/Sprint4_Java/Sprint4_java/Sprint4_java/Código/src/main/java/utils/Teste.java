package utils;

import controllers.CondutorVeiculo;
import controllers.Ocorrencia;
import controllers.Orcamento;
import controllers.Usuario;
import models.*;

import java.time.LocalDate;

public class Teste {
    public static <Mecânico> void main(String[] args) {
        // Teste de CondutorVeiculo
        CondutorVeiculo condutor = new CondutorVeiculo(
                "José da Silva",
                "123456789",
                "123.456.789-00",
                "12345678900",
                LocalDate.of(1990, 1, 15)
        );
        condutor.consultarInformacoes();
        System.out.println();

        Endereco endereco = new Endereco(
                "07054-340",
                "Rua Pastor Alemão",
                "Vila Regina",
                "222",
                "Próximo à praça"
        );

        // Teste de Telefone
        Telefone telefone = new Telefone("55", "11", "9585899544");

        // Teste de Usuário
        Usuario usuario = new Usuario(
                "usuario@exemplo.com",
                "usuario123",
                "senha123",
                telefone,
                endereco,
                LocalDate.of(1990, 1, 15)
        );
        usuario.consultarRegistro();
        System.out.println();

        // Teste de Veiculo
        Veiculo veiculo = new Veiculo(
                condutor,
                "FIAT",
                "Highline",
                LocalDate.of(2020, 1, 10),
                "A18E29"
        );
        veiculo.exibirInformacoes();
        System.out.println();

        // Teste de Mecânico
        Telefone telefoneMecanico = new Telefone("55", "11", "9585899544");
        Mecânico mecanico = (Mecânico) new Mecanico(
                "Carlos",   
                EspecialidadeMecanico.MOTOR,
                telefoneMecanico
        );
        mecanico.toString();
        System.out.println();

        // Teste de Ocorrencia
        Ocorrencia ocorrencia = new Ocorrencia(
                TipoOcorrencia.BATIDA_CARRO,
                LocalDate.of(2024, 5, 23),
                LocalDate.of(2024, 5, 23),
                "O carro teve uma batida traseira."
        );
        ocorrencia.registrarOcorrencia();
        System.out.println();

        // Teste de Orcamento
        Orcamento orcamento = new Orcamento(
                1000.0,
                TipoServico.MECANICA,
                TipoOrcamento.ESPECIAL,
                "Revisão completa e troca de óleo."
        );
        orcamento.consultarOrcamento();
        orcamento.calcularOrcamentoComDesconto();
    }
}
