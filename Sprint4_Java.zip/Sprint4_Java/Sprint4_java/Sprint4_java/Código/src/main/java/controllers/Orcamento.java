package controllers;

import models.TipoOrcamento;
import models.TipoServico;

public class Orcamento {
    private double valor;
    private TipoServico tipoDeServico;
    private TipoOrcamento tipoOrcamento;
    private String descricaoOrcamento;

    public Orcamento() {
    }

    public Orcamento(double valor, TipoServico tipoDeServico, TipoOrcamento tipoOrcamento, String descricaoOrcamento) {
        this.setValor(valor);
        this.setTipoDeServico(tipoDeServico);
        this.setTipoOrcamento(tipoOrcamento);
        this.setDescricaoOrcamento(descricaoOrcamento);
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public TipoServico getTipoDeServico() {
        return tipoDeServico;
    }

    public void setTipoDeServico(TipoServico tipoDeServico) {
        this.tipoDeServico = tipoDeServico;
    }

    public TipoOrcamento getTipoOrcamento() {
        return tipoOrcamento;
    }

    public void setTipoOrcamento(TipoOrcamento tipoOrcamento) {
        this.tipoOrcamento = tipoOrcamento;
    }

    public String getDescricaoOrcamento() {
        return descricaoOrcamento;
    }

    public void setDescricaoOrcamento(String descricaoOrcamento) {
        this.descricaoOrcamento = descricaoOrcamento;
    }

    public void ConsultarOrcamento() {
        System.out.println("Tipo de servico: " + getTipoDeServico());
        System.out.println("Tipo de orcamento: " + getTipoOrcamento());
        System.out.println("Descricao: " + getDescricaoOrcamento());
        System.out.println("Valor Estimado: " + getValor() + " REAIS");
    }

    public void consultarOrcamento() {
    }

    public void calcularOrcamentoComDesconto() {
    }
}
